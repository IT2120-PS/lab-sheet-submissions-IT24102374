setwd("C:\\Users\\IT24102374\\Desktop\\IT24102374")


#Import the dataset
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")
fix(branch_data)
attach(branch_data)


#Obtain boxplot for sales
boxplot(Sales_X1, main = "Boxplot for Sales", outline = TRUE, outpch = 8, horizontal = TRUE)


#Print five number summary for advertising
print(summary(branch_data$Advertising_X2))


#Print IQR for advertising
print(IQR(branch_data$Advertising_X2))


#Find the outliers
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25, na.rm = TRUE)
  Q3 <- quantile(x, 0.75, na.rm = TRUE)
  IQR <- Q3-Q1
  
  lower_bound <- Q1 - 1.5 * IQR
  upper_bound <- Q3 + 1.5 * IQR
  
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}


#Outliers in years
years_outliers <- find_outliers(branch_data$Years_X3)
print(years_outliers)

